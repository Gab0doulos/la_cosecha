<?php
class PlantillaControlador{

    public function CargarPlantilla(){
        include "Vistas/plantilla.php";
    }
}